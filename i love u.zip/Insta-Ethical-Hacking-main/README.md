# Insta-Ethical-Hacking
- An instagram project of what an educational phishing attack looks like

## Overview

- Web address of sample site for Instagram phishing:

https://instagram-bluetick.netlify.app/

![website_adress](https://user-images.githubusercontent.com/100594545/215474729-a8400b60-2db6-4030-863f-13ef757f6acc.PNG)

- Interface of the phishing site:

![instagram_login](https://user-images.githubusercontent.com/100594545/215474740-07e7fcaf-d8f2-4397-a6b3-afbc5d704901.PNG)

## Application

- Paste your discord webhook in the relevant place.
  
![img](https://user-images.githubusercontent.com/100594545/230425119-2607d974-3552-4e19-8409-3026fa09f16f.png)

- Notifying the user name and password to the system:
  
![215474748-1e1cd805-434a-42a5-8b8d-395ec651a8ba (1)](https://user-images.githubusercontent.com/100594545/221711148-624f5b47-d51c-4015-af58-ad2863a19745.png)

## Contributing

If you want to contribute to this project, please follow these steps:

- **Fork:** Fork this repository to your GitHub account.
- **Create a Branch:** Create a new branch to add a new feature or fix a bug.
- **Commit:** Add clear commit messages explaining your changes.
- **Push:** Push your changes to the repository you forked.
- **Pull Request:** Create a pull request on GitHub.
